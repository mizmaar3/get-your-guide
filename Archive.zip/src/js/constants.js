export const ElementIds = {
  INPUT_SEARCH: 'input-search-txt',
  INPUT_SUBMIT: 'input-submit-btn',
  CONTAINER_RESULTS: 'container-search-results',
  CONTAINER_FORM: 'container-search-form',
};
